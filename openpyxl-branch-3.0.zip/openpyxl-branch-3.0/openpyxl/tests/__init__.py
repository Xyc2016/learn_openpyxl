# Copyright (c) 2010-2021 openpyxl

import os

KEEP_VBA = os.environ.get("OPENPYXL_KEEP_VBA", "False") == "True"
